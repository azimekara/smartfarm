﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Concrete
{
    public class RoofActivity
    {
        public int Id { get; set; }
        public int ActivityType { get; set; }
    }
}
